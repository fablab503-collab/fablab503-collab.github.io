# Kilnform Studio — Applodian Style Study

**Kilnform** is an original static showcase and interactive vessel configurator for an architectural stoneware cup and botanical planter studio.

It is a design style study built from the **Applodian** design profile (`/Volumes/Volume1/SecondBrain/web-design-profiles/applodian/SKILL.md`), applying the measured layout rhythm, typography scale, colour palette (`#000000`, `#f5f5f7`, `#ffffff`, `#1d1d1f`, `#0071e3`, `#0066cc`, `#2997ff`), `980px` pill buttons, 44px dark global navigation, 12px white tile gutters, and responsive breakpoints (`1068px`, `734px`, `390px`) to an entirely original brand, copy, and hand-crafted inline SVG product range.

## How to Open

### 1. Open directly in any browser
No build step or external CDN is required. Double-click or open `index.html`:
```bash
open /Users/danielmadac/Developer/apps/cup-shop-applodian/index.html
```

### 2. Run a local static server (port 8765)
 matching `.claude/launch.json`:
```bash
cd /Users/danielmadac/Developer/apps/cup-shop-applodian
python3 -m http.server 8765
```
Then visit `http://localhost:8765/index.html` and `http://localhost:8765/customize.html`.

## Product Lineup & Capacities

- **Pebble** (`Small · 90 ml`, also customizable up to 600 ml) — Wide low-profile espresso & cortado cup (58 mm height).
- **Flute** (`Medium · 250 ml`, 90–600 ml) — Tall architectural fluted filter coffee cup (96 mm height).
- **Cairn** (`Big · 400 ml`, 90–600 ml) — Wide studio latte and ceremonial tea bowl cup (108 mm height).
- **Roam** (`Big · 400 ml`, 90–600 ml) — Hand-thrown stoneware tumbler with press-fit sip lid (126 mm height).
- **Hearth** (`Extra-Big · 600 ml`, 90–600 ml) — Oversized studio mug with forged three-finger loop handle (132 mm height).
- **Nomad** (`Extra-Big · 600 ml`, 90–600 ml) — Double-wall insulated ceramic travel cup with lock cap (178 mm height).
- **Terra Planter** (`1 L`, `3 L`, `8 L`) — Extra-big fluted stoneware plant pots with center drainage hole and fitted catch saucer (140 mm, 195 mm, and 265 mm heights).

## Files

- `index.html` — Full-bleed hero tiles, 2-column promo grid, Compare Cups table, and Apple-pattern footer.
- `customize.html` — Live SVG vessel configurator (family, segmented size pills, round glaze swatches, matte/glossy finish, live curved engraving text, quantity, `localStorage` shopping bag, and sticky summary buy bar).
- `styles.css` — Applodian `:root` tokens, typography scale, layout grid, responsive rules (`1068px`, `734px`, `390px`), and `prefers-reduced-motion` support.
- `app.js` — Parametric inline SVG cup/planter renderer, live price calculator, URL parameter loader, and `localStorage` demo bag.
- `.claude/launch.json` — Local static server configuration on port `8765`.
